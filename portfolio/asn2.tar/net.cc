
           /*****************************\
            *                           *
            *   CMPT 317        ASN2    *
            *   Logan Kopas   ljk003    *
            *          11095013         *
            *                           *
           \*****************************/

#include "net.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

/**
 * Creates a new bayes net
 */
Net* create_net()
{
    Net* new_net = (Net*) malloc( sizeof(Net) );
   
    // check some variables to make sure they are set to defaults 
    assert( new_net->class_v.values.num == 0);
    assert( new_net->class_v.values.total == 0);
    assert( new_net->evidence_v[255].t_values.total == 0);
    assert( new_net->evidence_v[255].f_values.num == 0);
    assert( new_net->evidence_v[255].toggle == UNOBSERVED);

    return new_net;
}

/**
 * Frees the memory associated with the bayes net
 */
void destroy_net(Net* net)
{
    free(net);
}

/**
 * Processes a line of information into the bayes net
 * uses helper function:            */
int process_ev(char*, bool, Net*);  /*
 * to recursively process evidence variables       
 */
int process_data(char* line, Net* net)
{
    if( line[0] == '\n' || line[0] == '\0' )
        return 0;
        
    char word[80];    

    // copy the variable name into a new string
    int i;
    for( i=0; i<80; i++ )
    {
        if( line[i] == ':' )
        {
            word[i] = '\0';
            break;
        }
        else
            word[i] = line[i];
    }
    line += i+1;

    // check if variable is class var and process
    if(! 0 == strcmp( net->class_v.name, word ))
        return 2;
    
    for( i=0; i<80; i++ )
    {
        if( line[i] == '\t' )
        {
            word[i] = '\0';
            break;
        }
        else
            word[i] = line[i];
    }   
    line += i+1;

    // store value of class variable for use with evidence vars
    bool prev = true;
    if( 0 == strcmp( word, "TRUE" ))
        net->class_v.values.num++;
    else if( 0 == strcmp( word, "FALSE" ))
        prev = false;
    else
        return 3;

    net->class_v.values.total++;

    // recursively process evidence variables
    return process_ev( line, prev, net);
}

/**
 * Helper function to process evidence variables
 */
int process_ev(char* line, bool prev, Net* net)
{
    if( line[0] == '\n' || line[0] == '\0' )
        return 0;
        
    char word[80];    

    // copy the variable name into a new string
    int i;
    for( i=0; i<80; i++ )
    {
        if( line[i] == ':' )
        {
            word[i] = '\0';
            break;
        }
        else
            word[i] = line[i];
    }
    line += i+1;

    // find the proper evidence variable
    EvidenceVar *var = find_ev( word, net );
    if( var == NULL )
        return 4;
     
    Pair* pair;
    if( prev )
        pair = &(var->t_values);
    else
        pair = &(var->f_values);
    
    for( i=0; i<80; i++ )
    {
        if( line[i] == '\t' || line[i] == '\n' )
        {
            word[i] = '\0';
            break;
        }
        else
            word[i] = line[i];
    }   
    line += i+1;

    if( 0 == strcmp( word, "TRUE" ))
        pair->num++;
    else if( 0 == strcmp( word, "FALSE" ))
        ;
    else
        return 5;
    pair->total++;
   
    // continue processing the rest of the evidence variables 
    return process_ev( line, prev, net);
}

/**
 * Searches through the evidence variable to find one that
 * matches the given name and returns a pointer to it
 */
EvidenceVar* find_ev(char* name,Net* net)
{
    // loop through and compare names
    for( int i=0; i<net->num_evs; i++ )
    {
        if( 0 == strcmp(name, net->evidence_v[i].name ))
            return &(net->evidence_v[i]);
    }
    return NULL;
}

/**
 * Determines the decimal ratio of the given variable
 */
float get_ratio(Pair p)
{
    return (float) p.num/(float) p.total;
}

/**
 * Determines the probability that the class variable is true
 * given the current state of all the evidence variables
 */
float query_net(Net* net)
{
    float numerator   = 0;
    float denominator = 0;

    // loop through all evidence variables, calculate only observed ones
    for( int i=0; i<net->num_evs; i++ )
    {
        EvidenceVar *cur = net->evidence_v + i;
        if( cur->toggle != UNOBSERVED )
        {
            denominator += get_ratio( cur->t_values );
            denominator += get_ratio( cur->f_values );
            if( cur->toggle == TRUE )
                numerator += get_ratio( cur->t_values );
            else
                numerator += get_ratio( cur->f_values );
        }
    }

    // if denominator is 0, then we have not observed any variables
    if( denominator == 0 )
        return 0;

    return numerator/denominator;
}
