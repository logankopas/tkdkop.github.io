
           /*****************************\
            *                           *
            *   CMPT 317        ASN2    *
            *   Logan Kopas   ljk003    *
            *          11095013         *
            *                           *
           \*****************************/

#ifndef _THE_PINK_PANTHER_
#define _THE_PINK_PANTHER_

enum Toggle { UNOBSERVED, TRUE, FALSE };

struct Pair {
    int num;
    int total;
};

struct ClassVar {
    char name[80];
    Pair values;
};

struct EvidenceVar {
    char name[80];
    Pair t_values;
    Pair f_values;
    Toggle toggle;
};

struct Net {
    ClassVar class_v;
    EvidenceVar evidence_v[512];
    int num_evs;
};

// Methods for Net structs
Net* create_net();
int process_data(char*, Net*);
void destroy_net(Net* net);
EvidenceVar* find_ev(char*,Net*);
float query_net(Net*);

// Pair methods
float get_ratio(Pair);

#endif //_THE_PINK_PANTHER_
