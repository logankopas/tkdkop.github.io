           /*****************************\
            *                           *
            *   CMPT 317        ASN2    *
            *   Logan Kopas   ljk003    *
            *          11095013         *
            *                           *
           \*****************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "net.h"

// Global Bayes Net
Net *bayes_net; 

/**
 * reads in the information from the given files
 * and constructs the bayes net
 */
int read_network(char *frame, char *data)
{
    FILE* f_frame;
    FILE* f_data;

    // open both files
    f_frame = fopen( frame, "r" );
    f_data = fopen( data, "r" );
    
    if( f_frame == NULL || f_data == NULL )
        return 1;
    
    // read in class variable
    fscanf(f_frame, "%s ", bayes_net->class_v.name);    
    
    // read in all evidence variables
    int i = 0;
    while( fscanf(f_frame,"%s ", bayes_net->evidence_v[i].name) != EOF )
        i++;

    bayes_net->num_evs = i;

    // read in lines from data file     
    char line[512];
    int retval;
    while( !feof(f_data) )
    {
        strcpy(line,"\0");
        fgets(line, 511, f_data);

        // process each line and store values in bayes net
        retval = process_data(line, bayes_net);
        if( retval != 0 )
        {
            printf("[**] Error: %d\n",retval);
            printf("[**] at %s\n",line);
        }
    }
    
    fclose(f_frame);
    fclose(f_data); 

    return 0;
}

/**
 * Print out the current state of the bayes net
 */
void display_network()
{
    // print class var and values
    printf( "Class Var: %s\n  total: %d\n  ratio: %f\n",
            bayes_net->class_v.name, bayes_net->class_v.values.total,
            get_ratio(bayes_net->class_v.values) );

    // print each evidence var and values
    for( int i=0; i<bayes_net->num_evs; i++ )
    {
        char observed[15];
        switch ( bayes_net->evidence_v[i].toggle )
        {
            case UNOBSERVED:
                strcpy(observed,"Unobserved");
                break;
            case TRUE:
                strcpy(observed, "True");
                break;
            case FALSE:
                strcpy(observed, "False");
                break;
        }

        printf( "Evidence Var: %s\n  %s\n  true total: %d\t\tfalse total: %d\
                \n  true ratio: %f\t\tfalse ratio %f\n",
                bayes_net->evidence_v[i].name, observed,
                bayes_net->evidence_v[i].t_values.total, 
                bayes_net->evidence_v[i].f_values.total,
                get_ratio( bayes_net->evidence_v[i].t_values ),
                get_ratio( bayes_net->evidence_v[i].f_values ) );
    }
}

/**
 * Main program, accepts files for bayes net 
 * and queries user for next step
 */
int main(int argc, char** argv)
{
    if( argc !=3 )
    {
        printf("Usage:\n\t\t./asn2 net_structure.txt net_data.txt\n");
        return -1;
    }
   
    bayes_net = create_net(); 

    read_network(argv[1], argv[2]);

    display_network();

    char c;
    char garbage[81];
    while( 1 )
    {
        // take user input
        printf( "What do you want to do\
            \nt/f/u:toggle evidence variable\tq:query\tx:exit\n" );
        
        scanf("%c",&c);
        fgets(garbage,80,stdin);

        if( c=='x' || c=='X' )
            break;
        else if( c == 'f' || c == 'F' || c == 't' || c == 'T'
                || c == 'u' || c == 'U' )
        {
            // loop until name is correct
            char var[80];
            printf("Enter name of evidence variable or \"quit\"\n");
            EvidenceVar *ev = NULL;
            while( ev == NULL )
            {
                scanf("%s", var);
                fgets(garbage,80,stdin);
                if( 0==strcmp(var,"quit") )
                    break;

                ev = find_ev(var, bayes_net);
                if( ev != NULL )
                {
                    switch ( c )
                    {
                        case 't':
                        case 'T':
                            ev->toggle = TRUE; 
                            break;
                        case 'f':
                        case 'F':
                            ev->toggle = FALSE;
                            break;
                        case 'u':
                        case 'U':
                            ev->toggle = UNOBSERVED;
                            break;
                    }

                }else{
                    printf("That name is not correct\n");
                }
            }
            display_network();   
        }
        else if( c == 'q' || c == 'Q' )
        {
            // query bayes net
            float results = query_net(bayes_net);
            if( results == 0 )
                printf( "Error, no observed variables\n" );
            else
                printf( "****************************\
                    \n\t\tresult: %f\n",results );
        }
        else
        {
            printf( "Invalid character\n" );
        }
    }

    // free memory
    destroy_net( bayes_net );
    return 0;
}
